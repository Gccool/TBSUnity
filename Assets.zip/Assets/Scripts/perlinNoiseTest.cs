using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class perlinNoiseTest : MonoBehaviour
{
    public int width;
    public int height;
    public float xOrg;
    public float yOrg;
   

    public float scale;

    private List<float> grayscale;
    public Tilemap[] tilemaps;
    public FloorTypes[] Tiles;
    public float HeightMutipler;
    public int OceanLevel;
    public Tilemap overlayMap;
    public Vector3Int MouseCellPos;
    public TileBase Arrow;
    public TileBase Blank;
    // Start is called before the first frame update
    void Start()
    {
        
        GenTerrain();
    }

    // Update is called once per frame
    void Update()
    {
        SpawnArrowsUnderCursor();
    }

    void GenTerrain()
    {
        for(int y = 0; y < height; y++)
        {
            for(int x = 0; x < width; x++)
            {
                
                float sample = Mathf.PerlinNoise((float)x / width * scale + xOrg, (float)y / height * scale + yOrg);
                //Debug.Log(sample);
                FloorTypes currentSpawn = Tiles[0];
                foreach(FloorTypes i in Tiles)
                {
                    if(sample > i.Heightfrom)
                    {
                        currentSpawn = i;
                    }
                }
                
                if(currentSpawn.IsOcean)
                {
                    tilemaps[Mathf.Clamp(OceanLevel, 0, tilemaps.Length - 1)].SetTile(new Vector3Int(x, y, 0), currentSpawn.TileImage);
                }
                else
                {
                    int j = (int)(sample * HeightMutipler);
                    tilemaps[Mathf.Clamp(j, 0, tilemaps.Length - 1)].SetTile(new Vector3Int(x, y, 0), currentSpawn.TileImage);
                    tilemaps[Mathf.Clamp(j - 1, 0, tilemaps.Length - 1)].SetTile(new Vector3Int(x, y, 0), currentSpawn.TileImage);
                    tilemaps[Mathf.Clamp(j - 2, 0, tilemaps.Length - 1)].SetTile(new Vector3Int(x, y, 0), currentSpawn.TileImage);
                    tilemaps[Mathf.Clamp(j - 3, 0, tilemaps.Length - 1)].SetTile(new Vector3Int(x, y, 0), currentSpawn.TileImage);
                    tilemaps[Mathf.Clamp(j - 4, 0, tilemaps.Length - 1)].SetTile(new Vector3Int(x, y, 0), currentSpawn.TileImage);
                }
                
            }
        }
    }

    void SpawnArrowsUnderCursor()
    {
        overlayMap.SetTile(MouseCellPos, Blank);
        Vector3 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        MouseCellPos = overlayMap.WorldToCell(mousePos);
        MouseCellPos = new Vector3Int((int)Mathf.Clamp(MouseCellPos.x - 8, 0, width - 1), (int)Mathf.Clamp(MouseCellPos.y - 8, 0, height - 1), 0);
        overlayMap.SetTile(MouseCellPos, Arrow);
    }
}
