using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using UnityEngine.Tilemaps;

[CreateAssetMenu(fileName = "ObjectType", menuName = "Terrain")]
public class FloorTypes : ScriptableObject
{
    public TileBase TileImage;
    public float Heightfrom;
    public bool IsOcean;
    public bool IsGround;
    public bool IsMountain;
    public bool IsSnow;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
