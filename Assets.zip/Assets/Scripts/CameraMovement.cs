using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraMovement : MonoBehaviour
{
    private Vector3 StartPosition;
    private Vector3 Diffrence;
    
    public float ZoomAmount;
    public float MaxZoom;
    public float MinZoom;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        MoveCamera();
    }

    void MoveCamera()
    {
        if(Input.GetKeyDown(KeyCode.Mouse2))
        {
            StartPosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        }
        if(Input.GetKey(KeyCode.Mouse2))
        {
            Diffrence = StartPosition - Camera.main.ScreenToWorldPoint(Input.mousePosition);
            transform.position += Diffrence;
        }
        float MouseScroll = Input.GetAxis("Mouse ScrollWheel");
        float j = (MouseScroll * ZoomAmount * -1) + Camera.main.orthographicSize;
        Camera.main.orthographicSize = Mathf.Clamp(j, MinZoom, MaxZoom);
    }
}
