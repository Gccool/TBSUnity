using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using UnityEngine.Tilemaps;

[CreateAssetMenu(fileName ="Unit", menuName = "Unit")]
public class UnitObject : ScriptableObject
{
   public TileBase Unit;
   public bool CanStandOnMountain;
   public bool CanStandOnSnow;
   public bool CanStandOnWater;
   
   public int movementRange;
}
