﻿namespace SuperTiled2Unity.Editor
{
    public class SuperAssetTileset : SuperAsset
    {
    }
}
