﻿namespace SuperTiled2Unity.Editor
{
    // Used to tag assets specific to SuperTiled2Unity
    public class SuperAssetSettings : SuperAsset
    {
    }
}
