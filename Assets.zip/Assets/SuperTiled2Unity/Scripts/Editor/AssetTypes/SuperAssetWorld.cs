﻿namespace SuperTiled2Unity.Editor
{
    public class SuperAssetWorld : SuperAsset
    {
    }
}
