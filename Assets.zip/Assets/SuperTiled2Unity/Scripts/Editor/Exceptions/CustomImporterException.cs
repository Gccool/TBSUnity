﻿using System;

namespace SuperTiled2Unity.Editor
{
    public class CustomImporterException : Exception
    {
        public CustomImporterException(string msg) : base(msg)
        {
        }
    }
}
