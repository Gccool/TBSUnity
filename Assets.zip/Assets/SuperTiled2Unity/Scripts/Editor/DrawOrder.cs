﻿namespace SuperTiled2Unity.Editor
{
    public enum DrawOrder
    {
        TopDown,
        Index,
    }
}
